#include"play_29_asdgames.cpp"

int main()
{
    Play_29_ASDgames game;
    game.play_asd_29();
    asdgraphics::cls();
    getch();
    return 0;
}
