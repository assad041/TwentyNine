#ifndef _PLAY_29_ASDGAMES_H_
#define _PLAY_29_ASDGAMES_H_

class Play_29_ASDgames
{
private:
    char ch;
public:
    int send_wining_messege(int win);
    void play_asd_29(void);
    void restart_A_new_deal(void);
    void restart_Game(void);
    char How_to_play(void);
    char Quit(void);
    char toolber_menu_option(char ch);

};

#endif
